chrome.runtime.onInstalled.addListener(() => {
  console.log('[iReady Overload] Extension installed');
});
