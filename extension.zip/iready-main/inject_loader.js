(() => {
  'use strict';

  const TAG = '[iReady-diag]';
  let recording = false;
  const captures = [];
  const MAX_FULL = 50_000;

  const now = () => new Date().toISOString();
  const snip = (s, n = 200) => typeof s === 'string' ? s.slice(0, n) : JSON.stringify(s)?.slice(0, n);

  function push(source, data, url) {
    if (!recording) return;
    try {
      const str = typeof data === 'string' ? data : JSON.stringify(data);
      if (!str || str.length < 20) return;
      captures.push({ ts: now(), source, url: url || null, snippet: snip(str, 300), full: str.slice(0, MAX_FULL) });
      console.debug(TAG, source, url || '', snip(str, 120));
    } catch (_) {}
  }

  const ANSWER_RE = /answer|correct|solution|score|response|choice|option|feedback|explanation|stimulus|passage|question/i;
  function isInteresting(str) {
    if (!str || str.length < 30) return false;
    return ANSWER_RE.test(str);
  }

  const origJSONParse = JSON.parse;
  const hookedParse = new Proxy(origJSONParse, {
    apply(target, thisArg, args) {
      const result = Reflect.apply(target, thisArg, args);
      try {
        if (recording && typeof args[0] === 'string' && isInteresting(args[0])) push('JSON.parse', args[0]);
      } catch (_) {}
      return result;
    }
  });
  JSON.parse = hookedParse;

  if (crypto?.subtle?.decrypt) {
    const origDecrypt = crypto.subtle.decrypt;
    const hookedDecrypt = new Proxy(origDecrypt, {
      apply(target, thisArg, args) {
        const prom = Reflect.apply(target, thisArg, args);
        if (!recording) return prom;
        return prom.then(result => {
          try {
            const bytes = new Uint8Array(result);
            const decoded = new TextDecoder().decode(bytes);
            if (decoded.length > 10) push('crypto.decrypt', decoded);
          } catch (_) {}
          return result;
        });
      }
    });
    crypto.subtle.decrypt = hookedDecrypt;
  }

  try {
    const po = new PerformanceObserver((list) => {
      if (!recording) return;
      for (const entry of list.getEntries()) {
        if (entry.initiatorType === 'fetch' || entry.initiatorType === 'xmlhttprequest') {
          if (isInteresting(entry.name)) push('network', { url: entry.name, duration: Math.round(entry.duration) }, entry.name);
        }
      }
    });
    po.observe({ type: 'resource', buffered: false });
  } catch (_) {}

  window.addEventListener('message', (ev) => {
    if (!recording) return;
    if (ev.data?._ireadyDiag) return;
    try {
      const str = typeof ev.data === 'string' ? ev.data : JSON.stringify(ev.data);
      if (str && isInteresting(str)) push('postMessage', str);
    } catch (_) {}
  });

  let scanInterval = null;
  function startDOMScan() {
    if (scanInterval) return;
    scanInterval = setInterval(() => {
      if (!recording) return;
      try {
        const selectors = [
          '[data-answer]', '[data-correct]', '[data-solution]',
          '[class*="answer"]', '[class*="correct"]', '[class*="solution"]',
          '[class*="feedback"]', '[class*="explanation"]',
          '[aria-label*="answer"]', '[aria-label*="correct"]',
          '.choice-text', '.answer-choice', '.response-option',
          '[class*="stimulus"]', '[class*="passage"]'
        ];
        for (const sel of selectors) {
          document.querySelectorAll(sel).forEach(el => {
            if (el._diagSeen) return;
            el._diagSeen = true;
            const data = {
              tag: el.tagName,
              class: el.className,
              text: (el.innerText || '').slice(0, 500),
              dataAttrs: {},
            };
            for (const attr of el.attributes) {
              if (attr.name.startsWith('data-')) data.dataAttrs[attr.name] = attr.value.slice(0, 200);
            }
            if (data.text.length > 5 || Object.keys(data.dataAttrs).length > 0) push('DOM', data);
          });
        }
      } catch (_) {}
    }, 2000);
  }

  document.addEventListener('_ireadyDiag', (ev) => {
    try {
      const cmd = ev.detail;
      if (cmd === 'start') {
        recording = true;
        captures.length = 0;
        startDOMScan();
        console.log(TAG, 'Recording started');
      }
      if (cmd === 'stop') {
        recording = false;
        console.log(TAG, 'Recording stopped, captured', captures.length, 'items');
      }
      if (cmd === 'get') {
        document.dispatchEvent(new CustomEvent('_ireadyDiagReply', { detail: JSON.stringify({ type: 'data', captures }) }));
      }
      if (cmd === 'status') {
        document.dispatchEvent(new CustomEvent('_ireadyDiagReply', { detail: JSON.stringify({ type: 'status', recording, count: captures.length }) }));
      }
    } catch(_) {}
  });

  console.log(TAG, 'Hooks installed. Waiting for record command.');
})();
