(() => { //you should always put comments in your code to explain what happens
  const pending = new Map();

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg._ir) return false;

    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    const cmd = Object.assign({}, msg._ir, { _id: id });

    pending.set(id, sendResponse);

    document.dispatchEvent(new CustomEvent('_irCmd', {
      detail: JSON.stringify(cmd)
    }));

    setTimeout(() => {
      if (pending.has(id)) {
        try { pending.get(id)({ error: 'timeout' }); } catch(e) {}
        pending.delete(id);
      }
    }, 15000);

    return true;
  });

  document.addEventListener('_irReply', (ev) => {
    try {
      const data = JSON.parse(ev.detail);
      if (data._id && pending.has(data._id)) {
        pending.get(data._id)(data);
        pending.delete(data._id);
      }
    } catch(e) {}
  });
})();
