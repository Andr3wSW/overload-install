(() => {
  'use strict';
  var TAG = '[iReady Overload]';
  var spyActive = false, diagActive = false, farmActive = false, farmUuid = null;
  var perfectMode = false;
  var spyLog = [];
  var capturedAuth = {};
  var lastSeenUuid = null;
  var stolenKeyHex = null;
  var stolenCryptoKey = null;
  var lastRealHeaders = {};
  var lastSignedPair = null;
  var interceptQueue = [];
  var interceptActive = false;
  var pendingHijack = null;
  var hijackResolve = null;

  function extractUUID(url) {
    var m = (typeof url === 'string' ? url : '').match(/\/lesson-assignment\/([0-9a-f-]{36})/);
    return m ? m[1] : null;
  }

  var _fetch = window.fetch;
  var _xhrOpen = XMLHttpRequest.prototype.open;
  var _xhrSend = XMLHttpRequest.prototype.send;
  var _xhrSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  var _importKey = crypto.subtle.importKey.bind(crypto.subtle);
  var _csSign = crypto.subtle.sign.bind(crypto.subtle);

  function hookImportKey(origFn, ctx) {
    return function(format, keyData, algorithm, extractable, keyUsages) {
      var algoName = typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name);
      var hashName = algorithm && algorithm.hash ? (typeof algorithm.hash === 'string' ? algorithm.hash : algorithm.hash.name) : '';
      var isHMAC = algoName === 'HMAC' || (hashName && hashName.indexOf('SHA') !== -1);
      var isSign = keyUsages && (keyUsages.indexOf('sign') !== -1 || keyUsages.indexOf('verify') !== -1);
      if (isHMAC && isSign && format === 'raw') {
        try {
          var raw = keyData instanceof ArrayBuffer ? keyData : (keyData.buffer ? new Uint8Array(keyData.buffer, keyData.byteOffset, keyData.byteLength) : keyData);
          var bytes = new Uint8Array(raw);
          if (bytes.length >= 16) {
            var hex = '';
            for (var i = 0; i < bytes.length; i++) hex += ('0' + bytes[i].toString(16)).slice(-2);
            stolenKeyHex = hex;
            console.log(TAG, 'STOLEN HMAC key via importKey (' + bytes.length + ' bytes):', hex.slice(0, 20) + '...');
          }
        } catch(e) { console.warn(TAG, 'importKey capture error:', e); }
      }
      return origFn.apply(ctx || this, arguments).then(function(key) {
        if (isHMAC && isSign) stolenCryptoKey = key;
        return key;
      });
    };
  }

  function hookSign(origFn, ctx) {
    return function(algorithm, key, data) {
      var algoName = typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name);
      if (algoName === 'HMAC') {
        stolenCryptoKey = key;
        console.log(TAG, 'Captured CryptoKey from sign() call');
      }
      return origFn.apply(ctx || this, arguments);
    };
  }

  crypto.subtle.importKey = hookImportKey(_importKey, crypto.subtle);
  crypto.subtle.sign = hookSign(_csSign, crypto.subtle);

  try {
    var _protoImportKey = SubtleCrypto.prototype.importKey;
    var _protoSign = SubtleCrypto.prototype.sign;
    SubtleCrypto.prototype.importKey = function() {
      var ctx = this;
      var algoName, isSign;
      try {
        var algorithm = arguments[2], keyUsages = arguments[4], format = arguments[0];
        algoName = typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name);
        var hashName = algorithm && algorithm.hash ? (typeof algorithm.hash === 'string' ? algorithm.hash : algorithm.hash.name) : '';
        isSign = keyUsages && (keyUsages.indexOf('sign') !== -1 || keyUsages.indexOf('verify') !== -1);
        if ((algoName === 'HMAC' || hashName.indexOf('SHA') !== -1) && isSign && format === 'raw') {
          var keyData = arguments[1];
          var raw = keyData instanceof ArrayBuffer ? keyData : (keyData.buffer ? new Uint8Array(keyData.buffer, keyData.byteOffset, keyData.byteLength) : keyData);
          var bytes = new Uint8Array(raw);
          if (bytes.length >= 16) {
            var hex = '';
            for (var i = 0; i < bytes.length; i++) hex += ('0' + bytes[i].toString(16)).slice(-2);
            stolenKeyHex = hex;
            console.log(TAG, 'STOLEN HMAC key via prototype (' + bytes.length + ' bytes):', hex.slice(0, 20) + '...');
          }
        }
      } catch(e) {}
      return _protoImportKey.apply(ctx, arguments).then(function(key) {
        if ((algoName === 'HMAC') && isSign) stolenCryptoKey = key;
        return key;
      });
    };
    SubtleCrypto.prototype.sign = function() {
      try {
        var algorithm = arguments[0];
        var algoName = typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name);
        if (algoName === 'HMAC') {
          stolenCryptoKey = arguments[1];
          console.log(TAG, 'Captured CryptoKey from prototype sign()');
        }
      } catch(e) {}
      return _protoSign.apply(this, arguments);
    };
  } catch(e) { console.warn(TAG, 'Prototype hooks failed:', e); }

  var signKeyVerified = false;
  var signVerifyLog = [];

  function hexToBytes(hex) {
    var bytes = new Uint8Array(hex.length / 2);
    for (var i = 0; i < hex.length; i += 2) bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
    return bytes;
  }

  function bufToB64(buf) {
    var a = new Uint8Array(buf), s = '';
    for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
    return btoa(s);
  }

  function computeHMAC(keyHex, message) {
    var keyBytes = hexToBytes(keyHex);
    return _importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
      .then(function(key) {
        return _csSign('HMAC', key, new TextEncoder().encode(message));
      })
      .then(function(buf) { return bufToB64(buf); });
  }

  function getSignKey() {
    if (!capturedAuth.Authorization) return null;
    var parts = capturedAuth.Authorization.split('/');
    return parts.length >= 2 ? parts[1] : null;
  }

  function computeSignature(requestId) {
    if (stolenCryptoKey) {
      return _csSign('HMAC', stolenCryptoKey, new TextEncoder().encode(requestId))
        .then(function(buf) { return 'keyId="algo_1", signature="' + bufToB64(buf) + '"'; })
        .catch(function(e) { console.warn(TAG, 'stolen key sign error:', e); return 'keyId="algo_1", signature="0x000000"'; });
    }
    if (stolenKeyHex) {
      return computeHMAC(stolenKeyHex, requestId).then(function(b64) {
        return 'keyId="algo_1", signature="' + b64 + '"';
      }).catch(function(e) { console.warn(TAG, 'signing error:', e); return 'keyId="algo_1", signature="0x000000"'; });
    }
    var keyHex = getSignKey();
    if (!keyHex) return Promise.resolve('keyId="algo_1", signature="0x000000"');
    return computeHMAC(keyHex, requestId).then(function(b64) {
      return 'keyId="algo_1", signature="' + b64 + '"';
    }).catch(function(e) {
      console.warn(TAG, 'signing error:', e);
      return 'keyId="algo_1", signature="0x000000"';
    });
  }

  function verifySignTheory(reqId, realSig) {
    if (signKeyVerified) return;
    function tryVerify(label, keyHex) {
      if (!keyHex) return Promise.resolve(false);
      return computeHMAC(keyHex, reqId).then(function(ourB64) {
        var match = realSig.indexOf(ourB64) !== -1;
        signVerifyLog.push({ reqId: reqId.slice(0, 16) + '...', match: match, src: label });
        if (signVerifyLog.length > 8) signVerifyLog.shift();
        if (match) {
          signKeyVerified = true;
          console.log(TAG, 'Signing VERIFIED via', label, '!');
        }
        return match;
      }).catch(function() { return false; });
    }
    var stolenKeyPromise = stolenCryptoKey
      ? _csSign('HMAC', stolenCryptoKey, new TextEncoder().encode(reqId)).then(function(buf) {
          var b64 = bufToB64(buf);
          var match = realSig.indexOf(b64) !== -1;
          if (match) { signKeyVerified = true; console.log(TAG, 'Signing VERIFIED via stolenCryptoKey!'); }
          return match;
        }).catch(function() { return false; })
      : Promise.resolve(false);
    stolenKeyPromise.then(function(ok) {
      if (ok) return;
      tryVerify('stolenHex', stolenKeyHex).then(function(ok2) {
        if (ok2) return;
        var derivedHex = getSignKey();
        if (derivedHex && derivedHex !== stolenKeyHex) tryVerify('derived', derivedHex);
      });
    });
  }

  function resolveUrl(u) {
    try { return new URL(u, location.href).href; } catch(e) { return u; }
  }
  function isIready(u) {
    return u.indexOf('i-ready.com') !== -1 || (u.charAt(0) === '/' && location.hostname.indexOf('i-ready.com') !== -1);
  }

  window.fetch = function(input, init) {
    try {
      var rawUrl = typeof input === 'string' ? input : (input && input.url ? input.url : '');
      var u = extractUUID(rawUrl);
      if (u) lastSeenUuid = u;
    } catch(e) {}
    try {
      var opts = init || {};
      if (opts.headers) {
        var hObj = null;
        if (opts.headers instanceof Headers) { hObj = {}; opts.headers.forEach(function(v,k){ hObj[k]=v; }); }
        else if (typeof opts.headers === 'object' && !(opts.headers instanceof Headers)) { hObj = opts.headers; }
        if (hObj) {
          if (hObj['Authorization'] || hObj['authorization']) capturedAuth['Authorization'] = hObj['Authorization'] || hObj['authorization'];
          if (hObj['Dashboard-Version']) capturedAuth['Dashboard-Version'] = hObj['Dashboard-Version'];
          if (hObj['Dashboard-Type']) capturedAuth['Dashboard-Type'] = hObj['Dashboard-Type'];
        }
      }
    } catch(e) {}
    if (!spyActive) return _fetch.apply(this, arguments);
    try {
      var raw = typeof input === 'string' ? input : (input && input.url ? input.url : String(input));
      if (!isIready(raw)) return _fetch.apply(this, arguments);
      var url = resolveUrl(raw);
      var opts = init || {};
      var entry = { t:'fetch', m:(opts.method||'GET').toUpperCase(), u:url, h:{}, b:null, ts:Date.now(), f:location.hostname };
      if (opts.headers) {
        try {
          if (opts.headers instanceof Headers) opts.headers.forEach(function(v,k){ entry.h[k]=v; });
          else if (typeof opts.headers === 'object') entry.h = JSON.parse(JSON.stringify(opts.headers));
        } catch(e){}
      }
      if (opts.body) try { entry.b = typeof opts.body === 'string' ? opts.body : null; } catch(e){}
      var idx = spyLog.length;
      spyLog.push(entry);
      return _fetch.apply(this, arguments).then(function(resp) {
        try {
          spyLog[idx].s = resp.status;
          resp.clone().text().then(function(t){ spyLog[idx].r = t.slice(0,3000); }).catch(function(){});
        } catch(e){}
        return resp;
      }).catch(function(err) {
        try { spyLog[idx].err = err.message; } catch(e){}
        throw err;
      });
    } catch(e) {
      return _fetch.apply(this, arguments);
    }
  };

  XMLHttpRequest.prototype.open = function(method, url) {
    this._irM = method; this._irU = url;
    try { var u = extractUUID(url); if (u) lastSeenUuid = u; } catch(e) {}
    return _xhrOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name === 'Authorization' || name === 'Dashboard-Version' || name === 'Dashboard-Type') {
      capturedAuth[name] = value;
    }
    if (!this._irAllH) this._irAllH = {};
    this._irAllH[name] = value;
    if (name === 'Signature') {
      lastRealHeaders = Object.assign({}, this._irAllH);
      if (this._irReqId) {
        lastSignedPair = { rid: this._irReqId, sig: value, time: Date.now(), headers: Object.assign({}, this._irAllH) };
        console.log(TAG, 'Captured signed pair from real traffic:', this._irReqId.slice(0,16) + '...');
      }
    }
    if (name === 'Request-ID') this._irReqId = value;
    if (name === 'Signature' && this._irReqId) {
      verifySignTheory(this._irReqId, value);
    }
    if (spyActive) {
      if (!this._irH) this._irH = {};
      this._irH[name] = value;
    }
    return _xhrSetHeader.apply(this, arguments);
  };

  function perfectify(bodyStr) {
    var p = JSON.parse(bodyStr);
    if (p.pldClaims) p.pldClaims.forEach(function(c) { c.numPoints = c.maxPoints; });
    if (p.reportingSkills) p.reportingSkills.forEach(function(s) { s.numPoints = s.maxPoints; });
    if (p.itemResults) p.itemResults.forEach(function(item) {
      if (item.pldId && item.attempts && item.attempts.length > 0) {
        item.score = 1;
        item.attempts = [{ scored: true, responses: item.attempts[0].responses.map(function(r) {
          return { inputId: r.inputId, type: r.type, correct: true, selections: r.selections };
        }) }];
      }
    });
    return JSON.stringify(p);
  }

  XMLHttpRequest.prototype.send = function(body) {
    var sendBody = body;
    var url = this._irU || '';
    if (perfectMode && sendBody && url.indexOf('/lesson-assignment/') !== -1 && url.indexOf('/complete') !== -1) {
      try { sendBody = perfectify(sendBody); console.log(TAG, 'Auto-perfected /complete body'); }
      catch(e) { console.warn(TAG, 'perfectify error:', e); }
    }
    if (diagActive && sendBody) {
      try {
        var p = JSON.parse(sendBody);
        var changed = false;
        if (p.correct === false) { p.correct = true; changed = true; }
        if (p.durationSeconds != null) { p.durationSeconds = 1000; changed = true; }
        if (changed) sendBody = JSON.stringify(p);
      } catch(e){}
    }
    if (spyActive) {
      try {
        var raw = this._irU || '';
        if (isIready(raw)) {
          var url = resolveUrl(raw);
          var entry = { t:'xhr', m:(this._irM||'?').toUpperCase(), u:url, h:this._irH||{}, b:null, ts:Date.now(), f:location.hostname };
          if (sendBody) try { entry.b = typeof sendBody === 'string' ? sendBody : null; } catch(e){}
          var idx = spyLog.length;
          spyLog.push(entry);
          var self = this;
          this.addEventListener('load', function() {
            try { spyLog[idx].s = self.status; spyLog[idx].r = (self.responseText||'').slice(0,3000); } catch(e){}
          });
        }
      } catch(e){}
    }
    if (interceptQueue.length > 0 && this._irAllH && this._irAllH['Signature'] && this._irAllH['Request-ID']) {
      var iq = interceptQueue.shift();
      interceptActive = true;
      console.log(TAG, 'INTERCEPTING real XHR! Stealing headers from', this._irU, '→', iq.url);
      var intXhr = new XMLHttpRequest();
      _xhrOpen.call(intXhr, iq.method, iq.url);
      var capturedH = Object.assign({}, this._irAllH);
      if (iq.method === 'POST') capturedH['Content-Type'] = 'application/json;charset=UTF-8';
      for (var hName in capturedH) {
        if (hName === 'Host' || hName === 'Origin' || hName === 'Referer') continue;
        try { _xhrSetHeader.call(intXhr, hName, capturedH[hName]); } catch(e) {}
      }
      intXhr.withCredentials = true;
      intXhr.onload = function() {
        console.log(TAG, 'Intercepted request result:', intXhr.status, intXhr.responseText.slice(0, 300));
        interceptActive = false;
        iq.resolve({ status: intXhr.status, ok: intXhr.status >= 200 && intXhr.status < 300, text: intXhr.responseText, method: 'intercept' });
      };
      intXhr.onerror = function() {
        console.warn(TAG, 'Intercepted request network error');
        interceptActive = false;
        iq.resolve({ status: 0, ok: false, text: 'network error', method: 'intercept' });
      };
      _xhrSend.call(intXhr, iq.body || null);
    }
    return _xhrSend.call(this, sendBody);
  };

  function queueIntercept(method, url, body) {
    return new Promise(function(resolve) {
      interceptQueue.push({ method: method, url: url, body: body, resolve: resolve });
      console.log(TAG, 'Queued intercept:', method, url, '(queue size:', interceptQueue.length + ')');
      setTimeout(function() {
        var idx = interceptQueue.findIndex(function(q) { return q.resolve === resolve; });
        if (idx !== -1) {
          interceptQueue.splice(idx, 1);
          console.warn(TAG, 'Intercept timeout — no real signed XHR came for', url);
          resolve({ status: 0, ok: false, text: 'intercept_timeout', method: 'timeout' });
        }
      }, 20000);
    });
  }

  function pokeApp() {
    var uuid = getUUID();
    if (uuid) {
      console.log(TAG, 'Poking app to generate signed traffic...');
      try { window.dispatchEvent(new Event('popstate')); } catch(e) {}
      try {
        var btns = document.querySelectorAll('button, [role="button"], .next-btn, [data-testid]');
        for (var i = 0; i < btns.length; i++) {
          var txt = (btns[i].textContent || '').toLowerCase();
          if (txt.indexOf('next') !== -1 || txt.indexOf('continue') !== -1 || txt.indexOf('start') !== -1) {
            console.log(TAG, 'Clicking button:', txt.trim().slice(0, 30));
            btns[i].click();
            break;
          }
        }
      } catch(e) {}
    }
  }

  async function signedRequest(method, url, body) {
    if (stolenCryptoKey || stolenKeyHex) {
      console.log(TAG, 'signedRequest: using stolen key for', method, url);
      var rid = (function(n){ var h=''; for(var i=0;i<n;i++) h+=Math.floor(Math.random()*16).toString(16); return h; })(64);
      var sig = await computeSignature(rid);
      var h = Object.assign({}, lastRealHeaders);
      h['Accept'] = h['Accept'] || 'application/json, text/plain, */*';
      h['Content-Type'] = 'application/json;charset=UTF-8';
      h['Authorization'] = capturedAuth.Authorization;
      h['Dashboard-Version'] = capturedAuth['Dashboard-Version'] || h['Dashboard-Version'] || 'release-16.8/2';
      h['Dashboard-Type'] = capturedAuth['Dashboard-Type'] || h['Dashboard-Type'] || 'MS';
      h['Request-ID'] = rid;
      h['Signature'] = sig;
      h['X-Signature'] = h['X-Signature'] || 'keyId="algo_1", signature="0x000000"';
      delete h['Host']; delete h['Origin']; delete h['Referer'];
      var r = await _fetch(url, { method: method, headers: h, credentials: 'include', body: body || undefined });
      var rText = await r.text();
      if (r.ok) return { status: r.status, ok: true, text: rText, method: 'stolenKey' };
      console.warn(TAG, 'Stolen key failed:', r.status, rText.slice(0, 200), '— falling through to intercept');
    }

    console.log(TAG, 'signedRequest: queueing intercept for', method, url);
    var interceptPromise = queueIntercept(method, url, body);
    setTimeout(function() { pokeApp(); }, 100);
    var result = await interceptPromise;
    if (result.ok) return result;
    console.warn(TAG, 'Intercept result:', result.status, (result.text || '').slice(0, 200));

    console.log(TAG, 'signedRequest: last resort unsigned for', method, url);
    var noSigH = {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json;charset=UTF-8',
      'Authorization': capturedAuth.Authorization,
      'Dashboard-Version': capturedAuth['Dashboard-Version'] || 'release-16.8/2',
      'Dashboard-Type': capturedAuth['Dashboard-Type'] || 'MS'
    };
    var r4 = await _fetch(url, { method: method, headers: noSigH, credentials: 'include', body: body || undefined });
    var r4Text = await r4.text();
    return { status: r4.status, ok: r4.ok, text: r4Text, method: 'noSig' };
  }

  function getUUID() {
    try {
      var entries = performance.getEntriesByType('resource');
      for (var i = entries.length - 1; i >= 0; i--) {
        var m = entries[i].name.match(/\/lesson-assignment\/([0-9a-f-]{36})/);
        if (m) return m[1];
      }
    } catch(e){}
    if (lastSeenUuid) return lastSeenUuid;
    try {
      var locM = (location.href + location.hash).match(/lesson-assignment[\/=]([0-9a-f-]{36})/i);
      if (locM) return locM[1];
    } catch(e){}
    if (window === window.top) {
      try {
        var iframes = document.querySelectorAll('iframe');
        for (var j = 0; j < iframes.length; j++) {
          var src = iframes[j].src || iframes[j].getAttribute('src') || '';
          var im = src.match(/lesson-assignment\/([0-9a-f-]{36})/);
          if (im) return im[1];
        }
      } catch(e){}
      try {
        var scripts = document.querySelectorAll('script[type="application/json"], [data-lesson], [data-assignment]');
        for (var k = 0; k < scripts.length; k++) {
          var sm = (scripts[k].textContent || scripts[k].getAttribute('data-lesson') || scripts[k].getAttribute('data-assignment') || '').match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/);
          if (sm) return sm[1];
        }
      } catch(e){}
    }
    return null;
  }

  function getLessonInfo() {
    if (window !== window.top) return null;
    try {
      if (document.querySelector('iframe[src*="cdn.i-ready.com"]') ||
          document.querySelector('iframe[src*="instructional-app"]') ||
          document.querySelector('iframe[src*="universe"]')) return 'mspro';
      if (document.getElementById('html5Iframe') || document.getElementById('closereading_lesson')) return 'legacy';
      if (document.getElementById('diagnosticIFrame') || document.querySelector('iframe[src*="diagnostic"]')) return 'diagnostic';
    } catch(e){}
    return null;
  }

  document.addEventListener('_irCmd', function(ev) {
    try {
      var cmd = JSON.parse(ev.detail);
      var reply = function(data) {
        data._id = cmd._id;
        document.dispatchEvent(new CustomEvent('_irReply', { detail: JSON.stringify(data) }));
      };

      switch(cmd.action) {
        case 'spy-start':
          spyActive = true; spyLog.length = 0;
          reply({ ok:true });
          break;

        case 'spy-stop':
          spyActive = false;
          reply({ ok:true, count:spyLog.length });
          break;

        case 'spy-dump':
          reply({ type:'spy-data', log:spyLog.slice(), frame:location.hostname });
          break;

        case 'diag-on':
          diagActive = true;
          reply({ ok:true, diag:true });
          break;

        case 'diag-off':
          diagActive = false;
          reply({ ok:true, diag:false });
          break;

        case 'get-uuid':
          reply({ uuid:getUUID(), frame:location.hostname });
          break;

        case 'get-lesson':
          reply({ lesson:getLessonInfo(), frame:location.hostname });
          break;

        case 'skip':
          if (!cmd.uuid) { reply({ ok:false, msg:'No UUID' }); break; }
          if (!capturedAuth.Authorization) { reply({ ok:false, msg:'No auth captured yet. Navigate around iReady first so the extension sees API traffic.' }); break; }
          (async function() {
            try {
              var base = 'https://login.i-ready.com/learning-delivery/student/lesson-assignment/' + cmd.uuid;
              var sigInfo = 'stolenCryptoKey=' + !!stolenCryptoKey + ' stolenHex=' + !!stolenKeyHex + ' lastSignedPair=' + !!lastSignedPair + ' interceptReady=true realHeaders=' + Object.keys(lastRealHeaders).length;
              console.log(TAG, 'SKIP starting. Auth:', capturedAuth.Authorization ? capturedAuth.Authorization.slice(0,20) + '...' : 'NONE');
              console.log(TAG, 'Signing state:', sigInfo);

              console.log(TAG, 'SKIP step 0: GET context', base + '/attempt/context');
              var ctxH = {
                'Accept': 'application/json, text/plain, */*',
                'Authorization': capturedAuth.Authorization,
                'Dashboard-Version': capturedAuth['Dashboard-Version'] || 'release-16.8/2',
                'Dashboard-Type': capturedAuth['Dashboard-Type'] || 'MS'
              };
              var ctxR = await _fetch(base + '/attempt/context', { method:'GET', headers:ctxH, credentials:'include' });
              var ctxT = await ctxR.text();
              console.log(TAG, 'context status:', ctxR.status, 'body:', ctxT.slice(0,500));
              if (!ctxR.ok) throw new Error('context ' + ctxR.status + ': ' + ctxT.slice(0,200));
              var ctx = JSON.parse(ctxT);
              console.log(TAG, 'context parsed: active=', ctx.active, 'attemptId=', ctx.attemptId, 'skills=', (ctx.reportingSkills||[]).length);
              var skills = (ctx.reportingSkills||[]).map(function(s) {
                return { id:s.id, numPoints:s.maxPoints||1, maxPoints:s.maxPoints||1, receivedInstructionAndPractice:null, receivedSupport:null };
              });
              var pldClaims = [];
              if (ctx.pldClaims && ctx.pldClaims.length) {
                pldClaims = ctx.pldClaims.map(function(c) { return { id:c.id, numPoints:c.maxPoints||1, maxPoints:c.maxPoints||1 }; });
              }

              if (!ctx.active || !ctx.attemptId) {
                console.log(TAG, 'SKIP step 1: POST start (trying all signing methods)...');
                var startR = await signedRequest('POST', base + '/start', null);
                console.log(TAG, 'start result: status=' + startR.status + ' method=' + startR.method + ' body=' + (startR.text||'').slice(0,500));
                if (!startR.ok) throw new Error('start ' + startR.status + ' (via ' + startR.method + '): ' + (startR.text||'').slice(0,200));
              } else {
                console.log(TAG, 'SKIP step 1: already active, skipping /start');
              }

              var body = JSON.stringify({ pldClaims:pldClaims, reportingSkills:skills, analyticsRecords:[], passageResults:[], itemResults:[] });
              console.log(TAG, 'SKIP step 2: POST complete, body:', body.slice(0,500));
              var compR = await signedRequest('POST', base + '/complete?allowTopicCompletion=false', body);
              console.log(TAG, 'complete result: status=' + compR.status + ' method=' + compR.method + ' body=' + (compR.text||'').slice(0,500));
              reply({ ok:compR.ok, status:compR.status, body:(compR.text||'').slice(0,500), signMethod:compR.method, hasKey:!!stolenCryptoKey||!!stolenKeyHex, stolenKey:!!stolenCryptoKey, signedPair:!!lastSignedPair, signVerified:signKeyVerified });
            } catch(e) {
              console.error(TAG, 'skip error:', e);
              reply({ ok:false, msg:e.message, hasKey:!!stolenCryptoKey||!!stolenKeyHex, stolenKey:!!stolenCryptoKey, signedPair:!!lastSignedPair, signVerified:signKeyVerified });
            }
          })();
          break;

        case 'farm-start':
          if (!cmd.uuid) { reply({ ok:false, msg:'No UUID' }); break; }
          farmUuid = cmd.uuid;
          _fetch('https://login.i-ready.com/learning-delivery/student/lesson-assignment/' + farmUuid + '/resume', {
            method:'POST', credentials:'include', headers:{ 'content-type':'application/json' }, body:'{}'
          }).then(function(r) {
            farmActive = r.ok;
            reply({ ok:r.ok, status:r.status, farmActive:farmActive });
          }).catch(function(e) { reply({ ok:false, msg:e.message }); });
          break;

        case 'farm-stop':
          if (farmUuid) {
            _fetch('https://login.i-ready.com/learning-delivery/student/lesson-assignment/' + farmUuid + '/pause', {
              method:'POST', credentials:'include', headers:{ 'content-type':'application/json' }, body:'{}'
            }).then(function(r) {
              farmActive = false;
              reply({ ok:r.ok, status:r.status, farmActive:false });
            }).catch(function(e) { reply({ ok:false, msg:e.message }); });
          } else {
            farmActive = false;
            reply({ ok:true, farmActive:false });
          }
          break;

        case 'perfect-on':
          perfectMode = true;
          reply({ ok:true, perfectMode:true });
          break;

        case 'perfect-off':
          perfectMode = false;
          reply({ ok:true, perfectMode:false });
          break;

        case 'get-sign-info':
          reply({
            hasKey: !!stolenCryptoKey || !!stolenKeyHex || !!getSignKey(),
            stolenKey: !!stolenCryptoKey,
            stolenHex: !!stolenKeyHex,
            signedPair: !!lastSignedPair,
            signedPairAge: lastSignedPair ? Math.round((Date.now() - lastSignedPair.time) / 1000) + 's' : null,
            interceptReady: true,
            interceptQueueSize: interceptQueue.length,
            verified: signKeyVerified,
            hasAuth: !!capturedAuth.Authorization,
            realHeaders: Object.keys(lastRealHeaders).length,
            verifyLog: signVerifyLog,
            frame: location.hostname
          });
          break;

        case 'export-key':
          reply({ ok: !!getSignKey(), keyHex: getSignKey(), verified: signKeyVerified, frame: location.hostname });
          break;

        case 'import-key':
          reply({ ok:false, msg:'import-key no longer needed — key is derived from Authorization' });
          break;

        case 'status':
          reply({ type:'status', spyActive:spyActive, diagActive:diagActive, farmActive:farmActive, farmUuid:farmUuid, perfectMode:perfectMode, spyCount:spyLog.length, frame:location.hostname, isTop:window===window.top, hasAuth:!!capturedAuth.Authorization, hasKey:!!stolenCryptoKey||!!stolenKeyHex||!!getSignKey(), stolenKey:!!stolenCryptoKey, signedPair:!!lastSignedPair, interceptReady:true, signVerified:signKeyVerified });
          break;
      }
    } catch(e) {
      console.warn(TAG, 'cmd error:', e);
    }
  });

  console.log(TAG, window === window.top ? 'TOP' : 'FRAME', location.hostname);
})();
