(() => {
  const spyBtn = document.getElementById('spyBtn');
  const dumpBtn = document.getElementById('dumpBtn');
  const skipBtn = document.getElementById('skipBtn');
  const perfectBtn = document.getElementById('perfectBtn');
  const farmBtn = document.getElementById('farmBtn');
  const diagBtn = document.getElementById('diagBtn');
  const logEl = document.getElementById('log');

  let spying = false, farming = false, diagOn = false, perfectOn = false, farmUuid = null;

  function log(msg) { logEl.textContent = msg; }

  async function getTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }

  async function sendToFrame(tabId, frameId, cmd) {
    try { return await chrome.tabs.sendMessage(tabId, { _ir: cmd }, { frameId }); }
    catch(e) { return null; }
  }

  async function sendToAllFrames(tabId, cmd) {
    try {
      const frames = await chrome.webNavigation.getAllFrames({ tabId });
      const results = [];
      for (const f of (frames || [])) {
        try {
          const r = await chrome.tabs.sendMessage(tabId, { _ir: cmd }, { frameId: f.frameId });
          if (r) results.push(r);
        } catch(e) {}
      }
      return results;
    } catch(e) { return []; }
  }

  async function findUUID(tabId) {
    const results = await sendToAllFrames(tabId, { action: 'get-uuid' });
    for (const r of results) { if (r && r.uuid) return r.uuid; }
    try {
      const injResults = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        func: () => {
          try {
            const entries = performance.getEntriesByType('resource');
            for (let i = entries.length - 1; i >= 0; i--) {
              const m = entries[i].name.match(/\/lesson-assignment\/([0-9a-f-]{36})/);
              if (m) return m[1];
            }
          } catch(e) {}
          return null;
        },
        world: 'MAIN'
      });
      for (const r of (injResults || [])) { if (r && r.result) return r.result; }
    } catch(e) {}
    return null;
  }

  spyBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    spying = !spying;
    await sendToAllFrames(tab.id, { action: spying ? 'spy-start' : 'spy-stop' });
    spyBtn.textContent = spying ? 'Stop Spy' : 'Start Spy';
    spyBtn.classList.toggle('on', spying);
    log(spying ? 'Spy active — do stuff in iReady, then dump' : 'Spy stopped');
  });

  dumpBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    log('Collecting from all frames...');
    const results = await sendToAllFrames(tab.id, { action: 'spy-dump' });
    let all = [];
    for (const r of results) { if (r && r.log) all.push.apply(all, r.log); }
    all.sort(function(a, b) { return a.ts - b.ts; });
    if (all.length === 0) { log('No data captured. Start spy first.'); return; }
    const json = JSON.stringify(all, null, 2);
    try {
      await navigator.clipboard.writeText(json);
      log('Copied ' + all.length + ' entries to clipboard!');
    } catch(e) {
      const blob = new Blob([json], { type: 'application/json' });
      chrome.tabs.create({ url: URL.createObjectURL(blob) });
      log(all.length + ' entries opened in new tab');
    }
  });

  skipBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    log('Finding lesson...');
    const uuid = await findUUID(tab.id);
    if (!uuid) { log('No lesson found. Open a lesson first.'); return; }
    log('UUID: ' + uuid.slice(0,8) + '... finding best frame...');

    const allFrames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
    let bestFrameId = 0;
    let bestInfo = null;
    let bestScore = 0;
    for (const f of (allFrames || [])) {
      try {
        const info = await chrome.tabs.sendMessage(tab.id, { _ir: { action: 'get-sign-info' } }, { frameId: f.frameId });
        if (info) {
          let score = 0;
          if (info.hasAuth) score += 1;
          if (info.hasKey) score += 2;
          if (info.signedPair) score += 3;
          if (info.stolenKey) score += 4;
          if (info.verified) score += 8;
          if (info.realHeaders > 0) score += 1;
          if (score > bestScore) { bestScore = score; bestFrameId = f.frameId; bestInfo = info; }
          if (info.stolenKey && info.hasAuth && info.verified) break;
        }
      } catch(e) {}
    }

    if (bestInfo && bestInfo.stolenKey) {
      log('Stolen key in ' + bestInfo.frame + (bestInfo.verified ? ' (verified)' : '') + '. Skipping...');
    } else if (bestInfo && bestInfo.hasAuth) {
      log('Auth in ' + bestInfo.frame + '. Will intercept next signed request. Skipping...');
    } else {
      log('Warning: No auth in any frame. Navigate around iReady first.');
    }

    const r = await sendToFrame(tab.id, bestFrameId, { action: 'skip', uuid: uuid });
    if (r && r.ok) {
      log('Lesson completed! (via ' + (r.signMethod || '?') + ')\nRefresh the page.\n' + (r.body || '').slice(0,200));
    } else {
      var info = 'Skip failed (frame ' + bestFrameId + '):\n';
      if (r) {
        info += 'Status: ' + (r.status || 'none') + '\n';
        info += 'Body: ' + (r.body || r.msg || 'empty') + '\n';
        info += 'Method: ' + (r.signMethod || 'none') + '\n';
        info += 'Tip: The intercept waits for the app to make a signed API call.\nClick around in the lesson to trigger traffic, then try Skip again.';
      } else {
        info += 'No response from content script';
      }
      log(info);
    }
  });

  perfectBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    perfectOn = !perfectOn;
    await sendToAllFrames(tab.id, { action: perfectOn ? 'perfect-on' : 'perfect-off' });
    perfectBtn.textContent = perfectOn ? 'Auto 100% ON' : 'Auto 100%';
    perfectBtn.classList.toggle('on', perfectOn);
    log(perfectOn ? 'Auto 100% ON — click through lesson, score will be maxed' : 'Auto 100% OFF');
  });

  farmBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    if (farming) {
      log('Stopping farm...');
      await sendToFrame(tab.id, 0, { action: 'farm-stop' });
      farming = false; farmUuid = null;
      farmBtn.textContent = 'Farm Minutes';
      farmBtn.classList.remove('on');
      log('Farm stopped — minutes saved');
      return;
    }
    log('Finding lesson...');
    const uuid = await findUUID(tab.id);
    if (!uuid) { log('No lesson found. Open a lesson first.'); return; }
    farmUuid = uuid;
    log('UUID: ' + uuid.slice(0,8) + '... starting...');
    const r = await sendToFrame(tab.id, 0, { action: 'farm-start', uuid: uuid });
    if (r && r.ok) {
      farming = true;
      farmBtn.textContent = 'Stop Farming';
      farmBtn.classList.add('on');
      log('Farming! Press again to stop.');
    } else {
      log('Farm failed: ' + (r ? (r.status || '') + ' ' + (r.msg || '') : 'no response'));
    }
  });

  diagBtn.addEventListener('click', async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    diagOn = !diagOn;
    await sendToAllFrames(tab.id, { action: diagOn ? 'diag-on' : 'diag-off' });
    diagBtn.textContent = diagOn ? 'Disable Diag Hack' : 'Enable Diag Hack';
    diagBtn.classList.toggle('on', diagOn);
    log(diagOn ? 'Diag hack ON — answers auto-corrected' : 'Diag hack OFF');
  });

  (async () => {
    const tab = await getTab();
    if (!tab || !tab.id) return;
    const results = await sendToAllFrames(tab.id, { action: 'status' });
    for (const r of results) {
      if (!r) continue;
      if (r.spyActive) { spying = true; spyBtn.textContent = 'Stop Spy'; spyBtn.classList.add('on'); }
      if (r.diagActive) { diagOn = true; diagBtn.textContent = 'Disable Diag Hack'; diagBtn.classList.add('on'); }
      if (r.perfectMode) { perfectOn = true; perfectBtn.textContent = 'Auto 100% ON'; perfectBtn.classList.add('on'); }
      if (r.farmActive) { farming = true; farmUuid = r.farmUuid; farmBtn.textContent = 'Stop Farming'; farmBtn.classList.add('on'); }
      if (r.spyCount > 0) log('Spy: ' + r.spyCount + ' entries from ' + r.frame);
      if (r.stolenKey && r.signVerified) log('Signing: stolen key verified ✅');
      else if (r.stolenKey) log('Signing: crypto key stolen ✅ (verifying...)');
      else if (r.hasAuth) log('Signing: auth captured ✅ — intercept ready');
      else if (r.isTop) log('Signing: waiting for auth...');
    }
  })();
})();
